CREATE INDEX sport ON skills(sport_lvl);
CREATE INDEX bussines_skill ON skills(bussines_skill_lvl);

CREATE INDEX it_lvl ON skills (python_lvl, sql_lvl, math_lvl);